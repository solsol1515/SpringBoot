package com.example.domain;

import lombok.Data;

@Data
public class MemberVO {
   
   private String userid;
   private String username;
   private String userpass;

}